@php
$configData = Helper::appClasses();
$container = 'container-fluid';
$containerNav = 'container-fluid';
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Add Service')

@section('vendor-style')
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/select2/select2.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/tagify/tagify.css')}}" />
<link rel="stylesheet" href="{{asset('assets/css/service.css')}}" />

@endsection

@section('vendor-script')
<script src="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.js')}}"></script>
<script src="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js')}}"></script>
<script src="{{asset('assets/vendor/libs/select2/select2.js')}}"></script>
<script src="{{asset('assets/vendor/libs/ckeditor/ckeditor.js')}}"></script>
<script src="{{asset('assets/vendor/libs/tagify/tagify.js')}}"></script>

@endsection
@section('page-style')
<style type="text/css">
    .ck-editor__editable {min-height: 200px;}
    img.upload_logo {
        cursor: pointer;
    }
    label.form-label {
        margin-top: 1rem;
    }
    input.device_urls, label.device_urls {
        display: none;
        margin-top: 1rem;
    }
    tags.tagify.form-control {
        height: 100px;
    }

</style>
@endsection


@section('content')

<!-- Validation Wizard -->
  <div class="col-12 mb-4">
    <h4 class="py-2 mb-2">
      <span class="text-muted fw-light">Add Service</span>
    </h4>
    <div id="" class="bs-stepper mt-2">
        @include('admin.service.top_header')
      <div class="bs-stepper-content">
        <form id="wizard-validation-form" class="needs-validation1" method="post" action="{{route('service.store')}}" enctype="multipart/form-data" novalidate>
            @csrf
          <!-- Account Details -->
          <div id="account-details-validation" class="content active">
            <div class="row g-3">
               <div class="row g-3">
                  <div class="row">
                    <div class="col-sm-3">
                        <img src="{{asset('assets/img/placeholder/company-logo.jpg')}}" class="img-fluid upload_logo">
                        <input type="file" class="form-control" name="logo" id="upload_logo" accept="image/*" required>
                    </div>
                    <div class="col-sm-9">
                      <div class="col-12 pb-2">
                        <label class="form-label required-label mt-0 " for="name">Company Name</label>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Company name" required />
                      </div>
                      <div class="col-12">
                        <label class="form-label required-label" for="tagline">Company Tagline</label>
                        <input type="text"  id="tagline" name="tagline" class="form-control" placeholder="Company Tagline" required/>
                      </div>
                    </div>
                    <div class="col-md-12">
                        <div class="company-logo-message-wrapper">
                            <div class="company-logo-message">
                                <div class="company-logo-message-text">Upload here your company logo. Image dimension should not be greater than 500 pixels. We recommend you to use sqaure image for better visibility.</div>
                            </div>
                        </div>
                    </div>
                  </div>
                  <div class="row">
                        <div class="col-md-4"> 
                            <label class="form-label required-label">Founded</label>
                            <input type="text" name="founded" class="form-control" placeholder="YYYY" maxlength="4" required>
                        </div>
                        <div class="col-md-4"> 
                            <label class="form-label required-label">Employees</label>
                            <select class="form-control" name="employees" required>
                                @foreach (EmployeesSize() as $key => $value)
                                    <option value="{{$key}}">{{$value}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4"> 
                            <label class="form-label required-label">Avg. Hourly Rate</label>
                            <select class="form-control" name="hourly_rate" required>
                                @foreach (HourlyRate() as $key => $value)
                                    <option value="{{$key}}">{{$value}}</option>
                                @endforeach
                            </select>
                        </div>
                  </div>
                  <div class="row">
                        <div class="col-md-6"> 
                            <label class="form-label required-label">Website</label>
                            <input type="url" name="website" class="form-control" placeholder="www.website.com" required>
                        </div>
                        <div class="col-md-6"> 
                            <label class="form-label required-label">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="company@email.com" required>
                        </div>
                  </div>
                  <div class="row">
                        <div class="col-md-6"> 
                            <label class="form-label required-label">Phone Number</label>
                            <input type="text" name="phone_number" class="form-control" placeholder="+1-123-123-1234" required>
                        </div>
                        <div class="col-md-6"> 
                            <label class="form-label">Facebook</label>
                            <input type="url" name="meta[facebook]" class="form-control" placeholder="www.facebook.com/profile">
                        </div>
                  </div>
                  <div class="row">
                        <div class="col-md-6"> 
                            <label class="form-label">Twitter</label>
                            <input type="text" name="meta[twitter]" class="form-control" placeholder="www.twitter.com/profile">
                        </div>
                        <div class="col-md-6"> 
                            <label class="form-label">LinkedIn</label>
                            <input type="url" name="meta[linkedin]" class="form-control" placeholder="www.linkedin.com/profile">
                        </div>
                  </div>
                  <div class="row">
                        <div class="col-12" >
                            <label class="form-label">Certifications</label>
                        </div>
                        @foreach (getCertifications() as $key => $value)
                            <div class="col-sm-4">
                                <label class="form-label"> <input type="checkbox" name="meta[certifications][]" value="{{$key}}"> {{$value}}</label>
                            </div>
                        @endforeach
                  </div>
                  <div class="row">
                       <div class="col-12"> 
                            <label class="form-label required-label">Company Summary (Max. 500 words)</label>
                            <textarea class="form-control ckeditor" name="summary" id="summary" required></textarea>
                       </div>
                       <div class="col-12"> 
                            <label class="form-label required-label">Services (Max. 500 words)</label>
                            <textarea class="form-control ckeditor"  rows="12" name="services" id="services" required></textarea>
                       </div>
                       <div class="col-12">
                            <label for="TagifyBasic" class="form-label required-label">Key Clients (mention here names of important projects, companies or clients you worked with)</label>
                            <input id="TagifyBasic" class="form-control" name="key_clients" value="" required />
                       </div>
                  </div>

              <div class="col-12 d-flex justify-content-between">
                <button class="btn btn-primary btn-next"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Save</span></button>
              </div>
            </div>
          </div>
          
        </form>
      </div>
    </div>
  </div>
<!-- /Validation Wizard -->
@endsection
@section('page-script')
<script src="{{asset('assets/js/forms-tagify.js')}}"></script>
  <script src="{{asset('assets/js/service.js')}}"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.ckeditor').each(function(e){
        ClassicEditor
            .create( this , {
                toolbar: [
                    'Bold','Italic','NumberedList','BulletedList'
                ],
                removeButtons: 'Subscript,Superscript',
                format_tags: 'p;h1;h2;h3;pre',
                pasteFromWordRemoveFontStyles: true,
                removeDialogTabs: 'image:advanced;link:advanced',
            })
            .then( editor => {
                editor.ui.view.editable.element.style.height = '200px';
            } )
            .catch( error => {
                console.error( error );
            } );
        });
        
    });
  </script>
@endsection