<div class="bs-stepper-header">
    <div class="step active" data-target="#account-details-validation">
      <button type="button" class="step-trigger">
        <span class="bs-stepper-circle">1</span>
        <span class="bs-stepper-label mt-1">
          <span class="bs-stepper-title">General Information</span>
        </span>
      </button>
    </div>
    <div class="line">
      <i class="ti ti-chevron-right"></i>
    </div>
    <div class="step" data-target="#personal-info-validation">
      <button type="button" class="step-trigger">
        <span class="bs-stepper-circle">2</span>
        <span class="bs-stepper-label">
          <span class="bs-stepper-title">Locations</span>
        </span>
      </button>
    </div>
    <div class="line">
      <i class="ti ti-chevron-right"></i>
    </div>
    <div class="step" data-target="#social-links-validation">
      <button type="button" class="step-trigger">
        <span class="bs-stepper-circle">3</span>
        <span class="bs-stepper-label">
          <span class="bs-stepper-title">Services</span>
        </span>
      </button>
    </div>
    <div class="line">
      <i class="ti ti-chevron-right"></i>
    </div>
    <div class="step" data-target="#social-links-validation">
      <button type="button" class="step-trigger">
        <span class="bs-stepper-circle">4</span>
        <span class="bs-stepper-label">
          <span class="bs-stepper-title">Clients & Industries</span>
        </span>
      </button>
    </div>
  </div>