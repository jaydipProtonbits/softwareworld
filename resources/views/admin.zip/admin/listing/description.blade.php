@php
$configData = Helper::appClasses();
$container = 'container-fluid';
$containerNav = 'container-fluid';
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Add Listing '. $type)

@section('vendor-style')
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/select2/select2.css')}}" />

@endsection

@section('vendor-script')
<script src="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.js')}}"></script>
<script src="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js')}}"></script>
<script src="{{asset('assets/vendor/libs/select2/select2.js')}}"></script>
@endsection
@section('page-style')
<style type="text/css">
    body button.step-trigger.activeBTN span.bs-stepper-title, 
    body button.step-trigger.activeBTN span.bs-stepper-subtitle {
        color: blue !important;
        font-weight: bold !important;
    }
    .activeBTN span.bs-stepper-circle {
        background: var(--bs-primary) !important;
        color: #FFF !important;
    }

    label.form-label {
        margin-top: 1rem;
    }
    #short_summary_count::after, .short_summary_count::after {
        content: "/250";
    }
    #summary_count::after, .summary_count::after {
        content: "/1000";
    }
    textarea {
        resize: none !important;
    }
    button.step-trigger {
        width: 100% !important;
        justify-content: space-between !important;
    }

</style>
@endsection


@section('content')
<h4 class="py-3 mb-4">
  <span class="text-muted fw-light">Update Listing</span>
</h4>
<div class="row">
  <!-- Vertical Icons Wizard -->
  <div class="col-12 mb-4">
    <div class="bs-stepper vertical wizard-vertical-icons-example mt-2">
      @include('admin.listing.sidebar')
        <form class="needs-validation1" action="{{route('saveDescription'
        ,[$type,$listing->id])}}" method="POST" enctype="maltipart/form-data" novalidate>
            @csrf
          <!-- Account Details -->
          <div id="account-details-vertical" class="content active">
            <div class="row g-3 category-box-description">
                <div class="col-12">
                    <h5>Default Description</h5>
                    <div class="form-group">
                        <span  class="float-end lighttagc pt-2 short_summary_count">0</span>
                        <label class="form-label required-label" for="short_description">Short Description</label>
                        <textarea rows="3" maxlength="250" cols="30" class="form-control category_short_summary" id="short_summary" name="short_description" required>{{$listing->getMeta('short_description')??''}}</textarea>
                        <div class="invalid-feedback">
                            Please enter Short Description.
                        </div>
                    </div>
                    <div class="form-group">
                        <span  class="float-end lighttagc pt-2 summary_count"></span>
                        <label class="form-label required-label" for="long_description">Long Description</label>
                        <textarea maxlength="1000" cols="30" rows="5" class="form-control category_summary" id="summary" name="long_description" required>{{$listing->getMeta('long_description')??''}}</textarea>
                        <div class="invalid-feedback">
                            Please enter Long Description.
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-5 category-box-description">
                    <h5>Category wise description</h5>
                    <div class="accordion mt-3" id="accordionStyle1">
                      @if(!empty($allCat = getCategory($listing->categories)))
                      @foreach ($allCat as $key => $value)
                          <div class="card accordion-item active">
                                <h2 class="accordion-header">
                                  <button type="button" class="accordion-button" data-bs-toggle="collapse" data-bs-target="#accordionStyle1-{{$value->id}}" aria-expanded="true">
                                    {{$value->name}}
                                  </button>
                                </h2>
                                <div id="accordionStyle1-{{$value->id}}" class="accordion-collapse collapse show" data-bs-parent="#accordionStyle1">
                                  <div class="accordion-body">
                                        <div class="form-group">
                                            <span class="float-end lighttagc pt-2 short_summary_count">0</span>
                                            <label class="form-label" for="short_description">Short Description</label>
                                            <textarea rows="3" maxlength="250" cols="30" class="form-control category_short_summary" id="short_summary" name="category_description[{{$value->id}}][short]">{{$listing->getMeta('category_description')[$value->id]['short']??''}}</textarea>
                                        </div>
                                        <div class="form-group">
                                            <span  class="float-end lighttagc pt-2 summary_count"></span>
                                            <label class="form-label" for="long_description">Long Description</label>
                                            <textarea maxlength="1000" cols="30" rows="5" class="form-control category_summary" id="summary" name="category_description[{{$value->id}}][long]">{{$listing->getMeta('category_description')[$value->id]['long']??''}}</textarea>
                                        </div>
                                  </div>
                                </div>
                            </div>    
                      @endforeach
                                          
                      @endif  

                    </div>
                    
                </div>
            </div>
          </div>
          <div class="mt-4 ms-auto">
            <input type="hidden" name="listing_id" value="{{$listing->id}}">
            <button class="btn btn-success btn-submit">Save & Next</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- /Vertical Icons Wizard -->
</div>
@endsection
@section('page-script')
<script src="{{asset('assets/js/listing.js')}}"></script>
  <script type="text/javascript">
    function countChar(val,ele,count) {
        var len = val.value.length;
        if (len <= count) {
          $(ele).text(len);
        } 
    }
    function countNewChar(val,ele,count)
    {
        var len = val.val().length;
        if (len <= count) {
          $(ele).text(len);
        } 
    }
    jQuery(document).ready(function($) {
        /*countChar(document.getElementById('summary'),'.summary_count',1000);
        countChar(document.getElementById('short_summary'),'.short_summary_count',250);*/
        
        $(document).on('keyup', '.category_short_summary', function () {
            countNewChar($(this),$(this).parents('.category-box-description').find('.short_summary_count'),250);
        });

        $(document).on('keyup', '.category_summary', function () {
            countNewChar($(this),$(this).parents('.category-box-description').find('.summary_count'),1000);
        });

        $(".category-box-description").each(function() {
            countNewChar($(this).find('.category_short_summary'),$(this).find('.short_summary_count'),250);
            countNewChar($(this).find('.category_summary'),$(this).find('.summary_count'),1000);
            
        });


    });
  </script>
@endsection
