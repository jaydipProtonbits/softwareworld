@php
$configData = Helper::appClasses();
$container = 'container-fluid';
$containerNav = 'container-fluid';
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Support & Training '. $type)

@section('vendor-style')
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/select2/select2.css')}}" />

@endsection

@section('vendor-script')
<script src="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.js')}}"></script>
<script src="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js')}}"></script>
<script src="{{asset('assets/vendor/libs/select2/select2.js')}}"></script>
@endsection
@section('page-style')
<style type="text/css">
    body button.step-trigger.activeBTN span.bs-stepper-title, 
    body button.step-trigger.activeBTN span.bs-stepper-subtitle {
        color: blue !important;
        font-weight: bold !important;
    }
    .activeBTN span.bs-stepper-circle {
        background: var(--bs-primary) !important;
        color: #FFF !important;
    }
    button.step-trigger {
        width: 100% !important;
        justify-content: space-between !important;
    }
    label.form-label {
        margin-top: 1rem;
    }
    .f-big input {
        width: 20px;
        height: 20px;
        vertical-align: middle;
    }
    .knowledge_box_enitity {
        display: flex;
        padding-bottom: 20px;
    }
    .remove-features, .remove-features-disabled, .remove-knowledge, .remove-knowledge-disabled {
        float: left;
        height: 24px;
        width: 24px;
        background: #ff5858;
        border-radius: 24px;
        line-height: 20px;
        color: #fff;
        text-align: center;
        font-size: 0;
        position: relative;
        top: 14px;
        cursor: pointer;
        color: transparent;
        flex: 0 0 24px;
    }
    .support_time_enitity .remove-features-disabled, .remove-knowledge, .remove-knowledge-disabled {
        margin-right: 12px;
        top: 11px;
    }
    .knowledge_type {
        width: 310px;
        margin-right: 20px;
    }
    .software-profile-box input.form-control, .reviewer-profile-box input.form-control {
        border: solid 1px #e4e8f2;
        height: 44px;
    }

    .software-profile-box .form-control, .reviewer-profile-box .form-control {
        font-size: 16px;
        color: #333;
        line-height: 1.5;
        padding: 10px 15px 11px;
        margin-top: 5px;
        max-width: none;
    }
    .knowledge_url {
        width: 310px;
    }
    .remove-features::before, .remove-features-disabled::before, .remove-knowledge::before, .remove-knowledge-disabled::before {
        background: #fff;
        height: 3px;
        width: 10px;
        content: "";
        display: inline-block;
        position: relative;
        top: 4px;
        left: 0;
    }
    .remove-features-disabled, .remove-knowledge-disabled {
        background: #c4c4c4;
        cursor: default;
    }
    
</style>
@endsection


@section('content')
<h4 class="py-3 mb-4">
  <span class="text-muted fw-light">Update Listing</span>
</h4>
<div class="row">
  <!-- Vertical Icons Wizard -->
  <div class="col-12 mb-4">
    <div class="bs-stepper vertical wizard-vertical-icons-example mt-2">
      @include('admin.listing.sidebar')
        <form class="needs-validation1" action="{{route('saveTraining'
        ,[$type,$listing->id])}}" method="POST" enctype="maltipart/form-data" novalidate>
            @csrf
          <!-- Account Details -->
          <div id="account-details-vertical" class="content active">
            <h5>Support & Training</h5>
            <div class="row g-3">
                <div class="col-12">
                  <label class="form-label d-block required-label">How do you provide support to your customers?</label>
                  <label class="f-big d-block mb-2">
                      <input type="checkbox" class="form-check-label" {{in_array('Email',$listing->getMeta('customer_support')) ? 'checked' : ''}} name="customer_support[]" value="Email"> Email 
                  </label>
                  <label class="f-big d-block mb-2">
                      <input type="checkbox" class="form-check-label" {{in_array('Chat',$listing->getMeta('customer_support')) ? 'checked' : ''}} name="customer_support[]" value="Chat"> Chat
                  </label>
                  <label class="f-big d-block">
                      <input type="checkbox" class="form-check-label" {{in_array('Phone',$listing->getMeta('customer_support')) ? 'checked' : ''}} name="customer_support[]" value="Phone"> Phone
                  </label>
                </div>
                <div class="col-12">
                  <label class="form-label d-block required-label">Do you provide 24x7 support to your customers?</label>
                  <label class="f-big">
                      <input type="radio" class="form-check-label" name="is_free_version" value="1"> YES 
                  </label>&nbsp;&nbsp;
                  <label class="f-big">
                      <input type="radio" class="form-check-label" name="is_free_version" value="0"> No
                  </label>
                </div>
                <div class="col-12">
                  <label class="form-label" for="support_email">Support Email</label>
                  <input type="text" name="support_email" id="support_email" class="form-control" placeholder="Enter Support Email">
                </div>
                <div class="col-12">
                  <label class="form-label d-block">How do you provide training for your software?</label>
                  <label class="f-big d-block mb-2">
                      <input type="checkbox" class="form-check-label" {{in_array('Webinar`',$listing->getMeta('provide_training')) ? 'checked' : ''}} name="provide_training[]" value="Webinar"> Webinar 
                  </label>
                  <label class="f-big d-block mb-2">
                      <input type="checkbox" class="form-check-label" {{in_array('In-person',$listing->getMeta('provide_training')) ? 'checked' : ''}} name="provide_training[]" value="In-person"> In-person
                  </label>
                  <label class="f-big d-block">
                      <input type="checkbox" class="form-check-label" {{in_array('Documentation',$listing->getMeta('provide_training')) ? 'checked' : ''}} name="provide_training[]" value="Documentation"> Documentation
                  </label>
                </div>
                <div class="col-12">
                    <label class="form-label d-block">Knowledge Base</label>
                    <div class="knowledge_box_lists">
                        @if (!empty($listing->getMeta('knowledge_base')))
                            @foreach ($listing->getMeta('knowledge_base') as  $key => $knowledge)
                                <div class="knowledge_box_enitity" id="knowledge_box_enitity_1">
                                    <span class="remove-knowledge">-</span>
                                    <div class="knowledge_type">
                                        <input name="knowledge_base[{{$key}}][type]" placeholder="Enter type title" class="form-control type valid" autocomplete="off" value="{{$knowledge['type']??''}}" type="text" maxlength="50" aria-invalid="false">
                                    </div>
                                    <div class="knowledge_url">
                                        <input name="knowledge_base[{{$key}}][url]" placeholder="Enter URL" class="form-control knowledge-url" value="{{$knowledge['url']??''}}" autocomplete="off" type="text">
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <div class="knowledge_box_enitity" id="knowledge_box_enitity_1">
                                <span class="remove-knowledge">-</span>
                                <div class="knowledge_type">
                                    <input name="knowledge_base[1][type]" placeholder="Enter type title" class="form-control type valid" autocomplete="off" value="" type="text" maxlength="50" aria-invalid="false">
                                </div>
                                <div class="knowledge_url">
                                    <input name="knowledge_base[1][url]" placeholder="Enter URL" class="form-control knowledge-url" value="" autocomplete="off" type="text">
                                </div>
                            </div>
                            <div class="knowledge_box_enitity" id="knowledge_box_enitity_2">
                                <span class="remove-knowledge">-</span>
                                <div class="knowledge_type">
                                    <input name="knowledge_base[2][type]" placeholder="Enter type title" class="form-control type" autocomplete="off" value="" type="text" maxlength="50">
                                </div>
                                <div class="knowledge_url">
                                    <input name="knowledge_base[2][url]" placeholder="Enter URL" class="form-control knowledge-url" value="" autocomplete="off" type="text">
                                </div>
                            </div>
                            <div class="knowledge_box_enitity" id="knowledge_box_enitity_3">
                                <span class="remove-knowledge">-</span>
                                <div class="knowledge_type">
                                    <input name="knowledge_base[3][type]" class="form-control type" placeholder="Enter type title" autocomplete="off" type="text" maxlength="50">
                                </div>
                                <div class="knowledge_url">
                                    <input name="knowledge_base[3][url]" class="form-control knowledge-url" placeholder="Enter URL" autocomplete="off" type="text">
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
                
              
              
            </div>
          </div>
          <div class="mt-4 ms-auto">
            <button class="btn btn-success btn-submit">Save & Publish</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- /Vertical Icons Wizard -->
</div>
@endsection
@section('page-script')
<script src="{{asset('assets/js/listing.js')}}"></script>

  <script type="text/javascript">
    function enablenewknowledgeBase(parent_div)
    {
        var str_box_len = $('.knowledge_box_enitity').length;
        var str_ind = $('#'+parent_div).index()+1;
        var target_div = $('#'+parent_div);

        if($.trim(target_div.find('.type').val()) || $.trim(target_div.find('.knowledge-url').val()))
        {
            var next_index =  str_ind + 1;

            var new_features = '<div class="knowledge_box_enitity" id="knowledge_box_enitity_'+next_index+'"><span class="remove-knowledge">-</span><div class="knowledge_type"><input name="knowledge_base['+next_index+'][type]" class="form-control type" placeholder="Enter type title" autocomplete="off" type="text" maxlength="50"></div><div class="knowledge_url"><input name="knowledge_base['+next_index+'][url]" class="form-control knowledge-url" placeholder="Enter URL" autocomplete="off" type="text"></div></div>';
            if(str_box_len == 1)
            {
                $('.knowledge_box_enitity').find('.remove-knowledge-disabled').addClass('remove-knowledge').removeClass('remove-knowledge-disabled');
                $('.knowledge_box_lists').append(new_features);
            }
            else if(str_ind == str_box_len)
            {
                if(str_ind >= 15)
                {
                    return false;
                }
                else
                    $('.knowledge_box_lists').append(new_features);
            }
        }
    }
    jQuery(document).ready(function($) {
        $(document).on('click', '.remove-knowledge', function (e) {
            //hideshowhelp('features');
            
            var str_box_len = $('.knowledge_box_enitity').length;
            
            if(str_box_len == 1)
            {
                // do not delete
                return false;
            }
            $(this).parents('.knowledge_box_enitity').remove();
            var newindx = 1;
            $('.knowledge_box_lists').find(".knowledge_box_enitity").each(function() {
                $(this).attr('id', 'knowledge_box_enitity_'+newindx);
                $(this).find('input.type').attr('name', 'knowledge_base['+newindx+'][type]');
                $(this).find('input.knowledge-url').attr('name', 'knowledge_base['+newindx+'][url]');
                newindx++;
            });
            str_box_len = $('.knowledge_box_enitity').length;
            if(str_box_len == 1)
            {
                $('.knowledge_box_enitity').find('.remove-knowledge').addClass('remove-knowledge-disabled').removeClass('remove-knowledge');
            }
        });
        $(document).on('keyup', 'input.type', function (e) {
            var parent_div = $(this).parents('.knowledge_box_enitity').attr('id');
            enablenewknowledgeBase(parent_div);
        });
        $(document).on('keyup', 'input.knowledge-url', function (e) {
            var parent_div = $(this).parents('.knowledge_box_enitity').attr('id');
            enablenewknowledgeBase(parent_div);
        });


    });
  </script>
@endsection
