@php
$configData = Helper::appClasses();
$container = 'container-fluid';
$containerNav = 'container-fluid';
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Update Listings')

@section('vendor-style')
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/select2/select2.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/@form-validation/umd/styles/index.min.css')}}" />

@endsection

@section('vendor-script')
<script src="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.js')}}"></script>
<script src="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js')}}"></script>
<script src="{{asset('assets/vendor/libs/select2/select2.js')}}"></script>
@endsection
@section('page-style')
<style type="text/css">
  body button.step-trigger.activeBTN span.bs-stepper-title, 
    body button.step-trigger.activeBTN span.bs-stepper-subtitle {
        color: blue !important;
        font-weight: bold !important;
    }
    .activeBTN span.bs-stepper-circle {
        background: var(--bs-primary) !important;
        color: #FFF !important;
    }
    img.upload_logo {
        cursor: pointer;
    }
    label.form-label {
        margin-top: 1rem;
    }
    input.device_urls, label.device_urls {
        display: none;
        margin-top: 1rem;
    }
    button.step-trigger {
        width: 100% !important;
        justify-content: space-between !important;
    }
    img.img-fluid.upload_logo {
      width: 192px;
      height: 134px;
      object-fit: cover;
  }

</style>
@endsection


@section('content')
<h4 class="py-3 mb-4">
  <span class="text-muted fw-light">Update Listing</span>
</h4>
<div class="row">
  <!-- Vertical Icons Wizard -->
  <div class="col-12 mb-4">
    <div class="bs-stepper vertical wizard-vertical-icons-example mt-2">
      @include('admin.listing.sidebar')
        <form class="needs-validation1" action="{{route('saveInformation'
        ,[$type,$listing->id])}}" method="POST" enctype="multipart/form-data" novalidate>
            @csrf
          <!-- Account Details -->
          <div id="account-details-vertical" class="content active">
            <div class="content-header mb-5">
              <h6 class="mb-0">Software information</h6>
              <small>Enter Your Software information.</small>
            </div>
            <div class="row g-3">
              <div class="row">
                <div class="col-sm-3">
                    <img src="{{(!empty($listing->logo)) ? asset('assets/company/'.$listing->logo) : asset('assets/img/placeholder/company-logo.jpg')}}" class="img-fluid upload_logo">
                    <input type="file" name="logo" id="upload_logo" class="">
                </div>
                <div class="col-sm-9">
                  <div class="col-12 pb-2">
                    <label class="form-label mt-0" for="name">Company Name</label>
                    <input type="text" id="name" name="name" value="{{$listing->name}}" class="form-control" placeholder="Company name" required />
                    <div class="invalid-feedback">
                      Please enter Company Name.
                    </div>
                  </div>
                  <div class="col-12">
                    <label class="form-label" for="tagline">Company Tagline</label>
                    <input type="text"  id="tagline" value="{{$listing->tagline}}" name="tagline" class="form-control" placeholder="Company Tagline" required />
                    <div class="invalid-feedback">
                      Please enter Company Tagline.
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <label class="form-label" for="website">Software Website</label>
                <input type="text" id="website" name="website" value="{{$listing->website}}" class="form-control" placeholder="https://website.com" aria-label="" required />
                <div class="invalid-feedback">
                    Please enter Software Website.
                  </div>
              </div>
              <div class="col-12">
                <label class="form-label" for="vendor_name">Vendor Name</label>
                <input type="text" id="vendor_name" name="vendor_name" value="{{$listing->vendor_name}}" class="form-control" placeholder="Vendor Name" aria-label="" required />
                <div class="invalid-feedback">
                    Please enter Vendor Name.
                </div>
              </div>
              <div class="col-12">
                <label class="form-label" for="year_founded">Vendor/Company Year Founded</label>
                <input type="text" id="year_founded" name="year_founded" value="{{$listing->getMeta('year_founded')}}"  class="form-control" placeholder="YYYY" aria-label="" required />
                <div class="invalid-feedback">
                    Please enter Vendor Name.
                </div>
              </div>
              <div class="col-12">
                  <label><b>Headquarter Address</b></label>
                  <div class="row">
                      <div class="col-sm-6">
                        <label class="form-label" for="country-dd">Country</label>
                        <select  id="country-dd" class="form-control" name="country" required>
                            <option></option>
                            @foreach ($countries as $data)
                            <option {{$data->id == $listing->getMeta('country') ? 'selected' : ''}} value="{{$data->id}}">
                                {{$data->name}}
                            </option>
                            @endforeach
                        </select>
                        <div class="invalid-feedback">
                             Please enter Country.
                         </div>
                      </div>
                      <div class="col-sm-6">
                        <label class="form-label" for="state-dd">State</label>
                        <select  id="state-dd" class="form-control" name="state" required>
                        </select>
                        <div class="invalid-feedback">
                             Please enter State.
                         </div>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-sm-6">
                        <label class="form-label" for="city-dd">City</label>
                        <select  id="city-dd" class="form-control" name="city" required>
                        </select>
                        <div class="invalid-feedback">
                             Please enter City.
                         </div>
                      </div>
                      <div class="col-sm-6">
                        <label class="form-label" for="street">Street</label>
                        <input type="text" id="street" value="{{$listing->getMeta('street')}}" name="street" class="form-control" placeholder="" aria-label="" required />
                        </select>
                        <div class="invalid-feedback">
                             Please enter Street.
                         </div>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-sm-6">
                        <label class="form-label" for="zip_code">Zip code</label>
                        <input type="text"  id="zip_code" value="{{$listing->getMeta('zip_code')}}" class="form-control" name="zip_code" required>
                        <div class="invalid-feedback">
                             Please enter Zip Code.
                         </div>
                        
                      </div>
                      <div class="col-sm-6">
                        <label class="form-label" for="contact_no">Contact Number</label>
                        <input type="text" id="contact_no" class="form-control" value="{{$listing->getMeta('contact_no')}}" name="contact_no" required>
                        <div class="invalid-feedback">
                             Please enter Contact Number.
                         </div>
                        
                      </div>
                  </div>
              </div>
              <div class="col-12">
                    <label class="form-label" for="category-dd">Software Category</label>
                    @php $categories = !empty($listing->categories) ? json_decode($listing->categories) : []; @endphp
                    <select  id="category-dd" class="form-control" multiple name="category[]" required>
                        <option></option>
                        @foreach ($category as $data)
                        <option {{ in_array($data->id,$categories) ? 'selected' : ''}} value="{{$data->id}}">
                            {{$data->name}}
                        </option>
                        @endforeach
                    </select>
                    <div class="invalid-feedback">
                        Please choose Categories.
                     </div>
              </div>
              <div class="col-12">
                    <label class="form-label d-block" for="include-country">
                    Include Countries
                        <small style="float: right;">
                            <label><input type="checkbox" {{$data->id == $listing->getMeta('all_include_country') ? 'selected' : ''}}  name="all_include_country" value="1" class="form-check-input"> Select All</label>
                        </small>
                    </label>
                    <select  id="include-country-dd" class="form-control" multiple name="include_countries[]" required>
                        <option></option>
                        @foreach ($countries as $data)
                            <option {{ in_array($data->id,$listing->getMeta('include_countries')??[]) ? 'selected' : ''}} value="{{$data->id}}">
                                {{$data->name}}
                            </option>
                        @endforeach
                    </select>
                    <div class="invalid-feedback">
                        Please choose Include Countries.
                     </div>
              </div>
              <div class="col-12">
                    <label class="form-label" for="languages_supported-dd">Include Languages</label>
                    <select  id="languages_supported-dd" class="form-control" multiple name="languages_supported[]" required>
                        <option></option>
                        @foreach (languagesSupported() as $key => $value): ?>
                        <option {{ in_array($key,$listing->getMeta('languages_supported',array())) ? 'selected' : ''}} value="{{$key}}">
                            {{$value}}
                        </option>
                        @endforeach
                    </select>
                     <div class="invalid-feedback">
                        Please choose Languages.
                     </div>
              </div>
              <div class="col-12">
                  <label class="form-label" for="target_industry-dd">Target Industries</label>
                  <select  id="target_industry-dd" class="form-control" multiple name="target_industry[]" required>
                      <option></option>
                      @foreach ($industries as $data): ?>
                      <option {{ in_array($data->id,$listing->getMeta('target_industry')??[]) ? 'selected' : ''}}  value="{{$data->id}}">
                          {{$data->name}}
                      </option>
                      @endforeach
                  </select>
                  <div class="invalid-feedback">
                     Please choose Target Industries.
                  </div>
              </div>
              <div class="col-12">
                  <label class="form-label" for="target_company_size-dd">Target Company Size</label>
                  <select  id="target_company_size-dd" class="form-control" name="target_company_size" required>
                      <option value="">Select Size</option>
                      @foreach (companySize() as $data): ?>
                        @if (!empty($data))
                        <option {{$data == $listing->getMeta('target_company_size') ? 'selected' : ''}} value="{{$data}}">
                            {{$data}}
                        </option>
                        @endif
                      @endforeach
                      
                  </select>
                  <div class="invalid-feedback">
                     Please choose Company Size.
                  </div>
              </div>
              <div class="col-12">
                  <label class="form-label d-block mb-3" for="licensing_model-dd">What is licensing model of your software?</label>
                  <label class="form-check-label" for="licensing_model">
                    <input name="licensing_model" class="form-check-input" type="radio" value="Proprietary" id="licensing_model" {{'Proprietary' == $listing->getMeta('licensing_model') ? 'checked' : ''}}> Proprietary</label>
                  <label class="form-check-label" for="licensing_model2">
                    <input name="licensing_model" class="form-check-input" type="radio" value="Open Source" id="licensing_model2" {{'Open Source' == $listing->getMeta('licensing_model') ? 'checked' : ''}}> Open Source</label>
              </div>
              <div class="col-12">
                  <label class="form-label d-block mb-3" for="licensing_model-dd">What is your software deployment type?</label>
                  
                  <label class="form-check-label" for="software_development_type">
                    <input name="software_development_type[]" class="form-check-input" type="checkbox" value="Cloud Hosted" id="software_development_type" {{ in_array('Cloud Hosted',$listing->getMeta('software_development_type')??[]) ? 'checked' : ''}}> Cloud Hosted
                  </label>

                  <label class="form-check-label" for="software_development_type2">
                    <input name="software_development_type[]" class="form-check-input" type="checkbox" value="Deployment Type" id="software_development_type2" {{ in_array('Deployment Type',$listing->getMeta('software_development_type')??[]) ? "checked" : ''}}> Deployment Type
                  </label>
              </div>
              <div class="col-12">
                  <label class="form-label d-block mb-3">Device Supported</label>
                  <?php foreach (deviceSupported() as $value): ?>
                      <label class="form-check-label d-block mt-1">
                        <input {{ in_array($value,$listing->getMeta('device_supported')??[]) ? 'checked' : ''}} name="device_supported[]" class="form-check-input" type="checkbox" value="{{$value}}" id="{{$value}}"> {{$value}}
                      </label>  
                  <?php endforeach ?>
              </div>
              <div class="col-12">
                <?php foreach (deviceSupported() as $value): ?>
                    <label class="form-check-label device_urls {{$value}}">{{$value}} URL</label>  
                      <input name="device_supported_url[{{$value}}]" class="form-control mt-0 device_urls {{$value}}" type="text" value="{{$listing->getMeta('device_supported_url')[$value] ?? ''}}">
                <?php endforeach ?>
              </div>
              <div class="col-12">

                <label class="form-check-label d-block mb-3"><b>Social Media Profiles</b></label>

                <?php foreach (socialMedia() as $value): ?>
                    <label class="form-check-label ">{{$value}}</label>  
                      <input name="social_profile[{{$value}}]" class="form-control mt-0 mb-2" type="text" value="{{$listing->getMeta('social_profile')[$value] ?? ''}}">
                <?php endforeach ?>
              </div>
              
            </div>
          </div>
          <div class="mt-4 ms-auto">
            <button class="btn btn-success btn-submit">Save & Next</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- /Vertical Icons Wizard -->
</div>
@endsection
@section('page-script')
<script src="{{asset('assets/js/listing.js')}}"></script>
   <script type="text/javascript">
     jQuery(document).ready(function($) {
      $('.bs-stepper.vertical button').click(function(event) {
         $url = $(this).data('url');
         if($url != '') {
            window.location.replace($url);
         }else {
            return false;
         }
      });
        $('.bs-stepper.vertical button').each(function(index, el) {
            $url = $(this).data('url');
            if ($url != '') {
               $(this).removeAttr('disabled');
            }
        });
     });
   </script>
  <script type="text/javascript">
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    

    jQuery(document).ready(function($) {

      setTimeout(function() {

        $('#country-dd').trigger('change');
        /*setTimeout(function() {
          $("#state-dd").val("{{$listing->getMeta('state')}}");
          $("#state-dd").trigger('change');
          setTimeout(function() {
            
            $("#city-dd").val("{{$listing->getMeta('city')}}");
            $("#city-dd").trigger('change');
          }, 100);
        }, 100);*/

        $('input[name="device_supported[]"]').each(function(index, el) {
            if($(this).is(':checked')){
              $(this).trigger('change');
            }
        });
      }, 500);

    $('input[name="device_supported[]"]').change(function(event) {
        if($(this).is(":checked")) {
            
            $('.device_urls.'+$(this).attr('id')).show();
        }else {
            $('.device_urls.'+$(this).attr('id')).hide();
        }
        
    });


    $('.upload_logo').click(function(event) {
        
          $('#upload_logo').click();
    });

    $("#country-dd").select2({
          placeholder: "Select Country",
          allowClear: true
      });

    $("#category-dd").select2({
          placeholder: "Search Categories",
          allowClear: true
      });

    $("#target_industry-dd").select2({
          placeholder: "Search Industry",
          allowClear: true
      });

    $("#include-country-dd").select2({
          placeholder: "Search Countries",
          allowClear: true
      });

    $("#languages_supported-dd").select2({
          placeholder: "Search Languages",
          allowClear: true
      });
      
    $("#city-dd").select2({
          placeholder: "Select City",
          allowClear: true
      });
      
    $("#state-dd").select2({
          placeholder: "Select State",
          allowClear: true
      });

       $('#country-dd').on('change', function () {
            var idCountry = this.value;
            $("#state-dd").html('');
            $.ajax({
                url: "{{url('api/fetch-states')}}",
                type: "POST",
                data: {
                    country_id: idCountry,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (result) {
                    $('#state-dd').html('<option value="">Select State</option>');
                    $.each(result.states, function (key, value) {
                        $("#state-dd").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                    $("#state-dd").select2("destroy").select2({
                          placeholder: "Select State",
                          allowClear: true
                      });

                    $("#state-dd").val("{{$listing->getMeta('state')}}");
                    $("#state-dd").trigger('change');

                    $('#city-dd').html('<option value="">Select City</option>');
                }
            });
        });
        $('#state-dd').on('change', function () {
            var idState = this.value;
            $("#city-dd").html('');
            $.ajax({
                url: "{{url('api/fetch-cities')}}",
                type: "POST",
                data: {
                    state_id: idState,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (res) {
                    $('#city-dd').html('<option value="">Select City</option>');
                    $.each(res.cities, function (key, value) {
                        $("#city-dd").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                    $("#city-dd").select2("destroy").select2({
                        placeholder: "Select City",
                        allowClear: true
                    });
                    $("#city-dd").val("{{$listing->getMeta('city')}}");
                    $("#city-dd").trigger('change');
                }
            });
        });



    });
  </script>
@endsection
