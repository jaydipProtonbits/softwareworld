@php
$configData = Helper::appClasses();
$container = 'container-fluid';
$containerNav = 'container-fluid';
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Add Listings')

@section('vendor-style')
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css')}}" />
<link rel="stylesheet" href="{{asset('assets/vendor/libs/select2/select2.css')}}" />

@endsection

@section('vendor-script')
<script src="{{asset('assets/vendor/libs/bs-stepper/bs-stepper.js')}}"></script>
<script src="{{asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js')}}"></script>
<script src="{{asset('assets/vendor/libs/select2/select2.js')}}"></script>
@endsection
@section('page-style')
<style type="text/css">
    img.upload_logo {
        cursor: pointer;
    }
    label.form-label {
        margin-top: 1rem;
    }
    input.device_urls, label.device_urls {
        display: none;
        margin-top: 1rem;
    }

</style>
@endsection


@section('content')
<h4 class="py-3 mb-4">
  <span class="text-muted fw-light">Add Listing</span>
</h4>
<div class="row">
  <!-- Vertical Icons Wizard -->
  <div class="col-12 mb-4">
    <div class="bs-stepper vertical wizard-vertical-icons-example mt-2">
      <div class="bs-stepper-header">
        <div class="step" data-target="#account-details-vertical">
          <button type="button" data-url="" class="step-trigger">
            <span class="bs-stepper-circle">
              <i class="ti ti-file-description"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Software information</span>
              <span class="bs-stepper-subtitle">Setup Software Details</span>
            </span>
          </button>
        </div>
        <div class="line"></div>
        <div class="step" data-target="#personal-info-vertical">
          <button type="button" data-url="" disabled="disabled" class="step-trigger">
            <span class="bs-stepper-circle">
              <i class="ti ti-user"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Description</span>
              <span class="bs-stepper-subtitle">Add Description</span>
            </span>
          </button>
        </div>
        <div class="line"></div>
        <div class="step" data-target="#social-links-vertical">
          <button type="button" data-url="" disabled="disabled" class="step-trigger">
            <span class="bs-stepper-circle"><i class="ti ti-brand-instagram"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Features</span>
              <span class="bs-stepper-subtitle">Add Features</span>
            </span>
          </button>
        </div>
        <div class="line"></div>
        <div class="step" data-target="#social-links-vertical">
          <button type="button" data-url="" disabled="disabled" class="step-trigger">
            <span class="bs-stepper-circle"><i class="ti ti-brand-instagram"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Media</span>
              <span class="bs-stepper-subtitle">Add Media</span>
            </span>
          </button>
        </div>
        <div class="line"></div>
        <div class="step" data-target="#social-links-vertical">
          <button type="button" data-url="" disabled="disabled" class="step-trigger">
            <span class="bs-stepper-circle"><i class="ti ti-brand-instagram"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Destination URLs</span>
              <span class="bs-stepper-subtitle">Add Destination URLs</span>
            </span>
          </button>
        </div>
        <div class="line"></div>
        <div class="step" data-target="#social-links-vertical">
          <button type="button" data-url="" disabled="disabled" class="step-trigger">
            <span class="bs-stepper-circle"><i class="ti ti-brand-instagram"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Pricing</span>
              <span class="bs-stepper-subtitle">Add Pricing & plans</span>
            </span>
          </button>
        </div>
        <div class="line"></div>
        <div class="step" data-target="#social-links-vertical">
          <button type="button" data-url="" disabled="disabled" class="step-trigger">
            <span class="bs-stepper-circle"><i class="ti ti-brand-instagram"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Integration & API</span>
              <span class="bs-stepper-subtitle">Add Integration & API</span>
            </span>
          </button>
        </div>
        <div class="line"></div>
        <div class="step" data-target="#social-links-vertical">
          <button type="button" data-url="" disabled="disabled" class="step-trigger">
            <span class="bs-stepper-circle"><i class="ti ti-brand-instagram"></i>
            </span>
            <span class="bs-stepper-label">
              <span class="bs-stepper-title">Support Training</span>
              <span class="bs-stepper-subtitle">Add Support details</span>
            </span>
          </button>
        </div>
      </div>
      <div class="bs-stepper-content">
        @if(count($errors) > 0 )
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="p-0 m-0" style="list-style: none;">
                @foreach($errors->all() as $error)
                <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
        @endif
        <form class="needs-validation1" action="{{route('listing.store')}}" method="POST" enctype="multipart/form-data" novalidate>
            @csrf
          <!-- Account Details -->
          <div id="account-details-vertical" class="content active">
            <div class="content-header mb-5">
              <h6 class="mb-0">Software information</h6>
              <small>Enter Your Software information.</small>
            </div>
            <div class="row g-3">
              <div class="row">
                <div class="col-sm-3">
                    <img src="{{asset('assets/img/placeholder/company-logo.jpg')}}" class="img-fluid upload_logo">
                    <input type="file" class="form-control" name="logo" id="upload_logo" required >
                </div>
                <div class="col-sm-9">
                  <div class="col-12 pb-2">
                    <label class="form-label required-label mt-0 " for="name">Company Name</label>
                    <input type="text" id="name" name="name" class="form-control" placeholder="Company name" required />
                  </div>
                  <div class="col-12">
                    <label class="form-label required-label" for="tagline">Company Tagline</label>
                    <input type="text"  id="tagline" name="tagline" class="form-control" placeholder="Company Tagline" required/>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <label class="form-label required-label" for="website">Software Website</label>
                <input type="text" id="website" name="website" class="form-control" placeholder="https://website.com" aria-label="" required/>
              </div>
              <div class="col-12">
                <label class="form-label required-label" for="vendor_name">Vendor Name</label>
                <input type="text" id="vendor_name" name="vendor_name" class="form-control" placeholder="Vendor Name" aria-label="" required />
              </div>
              <div class="col-12">
                <label class="form-label required-label" for="year_founded">Vendor/Company Year Founded</label>
                <input type="text" id="year_founded" name="year_founded" class="form-control" required placeholder="YYYY" aria-label="" />
              </div>
              <div class="col-12">
                  <label><b>Headquarter Address</b></label>
                  <div class="row">
                      <div class="col-sm-6">
                        <label class="form-label required-label" for="country-dd">Country</label>
                        <select  id="country-dd" class="form-control" name="country" required>
                            <option></option>
                            @foreach ($countries as $data)
                            <option value="{{$data->id}}">
                                {{$data->name}}
                            </option>
                            @endforeach
                        </select>
                      </div>
                      <div class="col-sm-6">
                        <label class="form-label required-label" for="state-dd">Country</label>
                        <select  id="state-dd" class="form-control" name="state" required>
                        </select>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-sm-6">
                        <label class="form-label required-label" for="city-dd">City</label>
                        <select  id="city-dd" class="form-control" name="city" required>
                        </select>
                      </div>
                      <div class="col-sm-6">
                        <label class="form-label required-label" for="street">Street</label>
                        <input type="text" id="street" name="street" class="form-control" placeholder="" aria-label="" required />
                        </select>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-sm-6">
                        <label class="form-label required-label" for="zip_code">Zip code</label>
                        <input type="text"  id="zip_code" class="form-control" name="zip_code" required>
                        
                      </div>
                      <div class="col-sm-6">
                        <label class="form-label required-label" for="contact_no">Contact Number</label>
                        <input type="text" id="contact_no" class="form-control" name="contact_no" required>
                        
                      </div>
                  </div>
              </div>
              <div class="col-12">
                    <label class="form-label required-label" for="category-dd">Software Category</label>
                    <select  id="category-dd" class="form-control" multiple name="category[]" required>
                        <option></option>
                        @foreach ($category as $data)
                        <option value="{{$data->id}}">
                            {{$data->name}}
                        </option>
                        @endforeach
                    </select>
              </div>
              <div class="col-12">
                    <label class="form-label required-label d-block" for="include-country">
                    Include Countries
                        <small style="float: right;">
                            <label><input type="checkbox" name="all_include_country" value="1" class="form-check-input"> Select All</label>
                        </small>
                    </label>
                    <select  id="include-country-dd" class="form-control" multiple name="include_countries[]" required>
                        <option></option>
                        @foreach ($countries as $data)
                            <option value="{{$data->id}}">
                                {{$data->name}}
                            </option>
                        @endforeach
                    </select>
              </div>
              <div class="col-12">
                    <label class="form-label required-label" for="languages_supported-dd">Include Languages</label>
                    <select  id="languages_supported-dd" class="form-control" multiple name="languages_supported[]" required>
                        <option></option>
                        @foreach (languagesSupported() as $key => $value): ?>
                        <option value="{{$key}}">
                            {{$value}}
                        </option>
                        @endforeach
                    </select>
              </div>
              <div class="col-12">
                  <label class="form-label required-label" for="target_industry-dd">Target Industries</label>
                  <select  id="target_industry-dd" class="form-control" multiple name="target_industry[]" required>
                      <option></option>
                      @foreach ($industries as $data): ?>
                      <option value="{{$data->id}}">
                          {{$data->name}}
                      </option>
                      @endforeach
                  </select>
              </div>
              <div class="col-12">
                  <label class="form-label required-label" for="target_company_size-dd">Target Company Size</label>
                  <select  id="target_company_size-dd" class="form-control" name="target_company_size[]" required>
                      <option value="">Select Size</option>
                      @foreach (companySize() as $data): ?>
                        @if (!empty($data))
                        <option value="{{$data}}">
                            {{$data}}
                        </option>
                        @endif
                      @endforeach
                      
                  </select>
              </div>
              <div class="col-12">
                  <label class="form-label required-label d-block mb-3" for="licensing_model-dd">What is licensing model of your software?</label>
                  <label class="form-check-label" for="licensing_model"><input name="licensing_model" class="form-check-input" type="radio" value="Proprietary" id="licensing_model" checked=""> Proprietary</label>
                  <label class="form-check-label" for="licensing_model2"><input name="licensing_model" class="form-check-input" type="radio" value="Open Source" id="licensing_model2"> Open Source</label>
              </div>
              <div class="col-12">
                  <label class="form-label required-label d-block mb-3" for="licensing_model-dd">What is your software deployment type?</label>
                  
                  <label class="form-check-label" for="software_development_type">
                    <input name="software_development_type[]" class="form-check-input" type="checkbox" value="Cloud Hosted" id="software_development_type"> Cloud Hosted
                  </label>

                  <label class="form-check-label" for="software_development_type2">
                    <input name="software_development_type[]" class="form-check-input" type="checkbox" value="Deployment Type" id="software_development_type2"> Deployment Type
                  </label>
              </div>
              <div class="col-12">
                  <label class="form-label required-label d-block mb-3">Device Supported</label>
                  <?php foreach (deviceSupported() as $value): ?>
                      <label class="form-check-label d-block mt-1">
                        <input name="device_supported[]" class="form-check-input" type="checkbox" value="{{$value}}" id="{{$value}}"> {{$value}}
                      </label>  
                  <?php endforeach ?>
              </div>
              <div class="col-12">
                <?php foreach (deviceSupported() as $value): ?>
                    <label class="form-check-label device_urls {{$value}}">{{$value}} URL</label>  
                      <input name="device_supported_url[{{$value}}]" class="form-control mt-0 device_urls {{$value}}" type="text" value="">
                <?php endforeach ?>
              </div>
              <div class="col-12">

                <label class="form-check-label d-block mb-3"><b>Social Media Profiles</b></label>

                <?php foreach (socialMedia() as $value): ?>
                    <label class="form-check-label ">{{$value}}</label>  
                      <input name="social_profile[{{$value}}]" class="form-control mt-0 mb-2" type="text" value="">
                <?php endforeach ?>
              </div>
              
            </div>
          </div>
          <div class="mt-4 ms-auto">
            <button class="btn btn-success btn-submit">Save & Next</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!-- /Vertical Icons Wizard -->
</div>
@endsection
@section('page-script')
<script src="{{asset('assets/js/listing.js')}}"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {

    $('input[name="device_supported[]"]').change(function(event) {
        if($(this).is(":checked")) {
            console.log($(this).attr('id'));
            $('.device_urls.'+$(this).attr('id')).show();
        }else {
            $('.device_urls.'+$(this).attr('id')).hide();
        }
        
    });


    $('.upload_logo').click(function(event) {
        console.log('click');
          $('#upload_logo').click();
    });

    $("#country-dd").select2({
          placeholder: "Select Country",
          allowClear: true
      });

    $("#category-dd").select2({
          placeholder: "Search Categories",
          allowClear: true
      });

    $("#target_industry-dd").select2({
          placeholder: "Search Industry",
          allowClear: true
      });

    $("#include-country-dd").select2({
          placeholder: "Search Countries",
          allowClear: true
      });

    $("#languages_supported-dd").select2({
          placeholder: "Search Languages",
          allowClear: true
      });
      
    $("#city-dd").select2({
          placeholder: "Select City",
          allowClear: true
      });
      
    $("#state-dd").select2({
          placeholder: "Select State",
          allowClear: true
      });

       $('#country-dd').on('change', function () {
            var idCountry = this.value;
            $("#state-dd").html('');
            $.ajax({
                url: "{{url('api/fetch-states')}}",
                type: "POST",
                data: {
                    country_id: idCountry,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (result) {
                    $('#state-dd').html('<option value="">Select State</option>');
                    $.each(result.states, function (key, value) {
                        $("#state-dd").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                    $("#state-dd").select2("destroy").select2({
                          placeholder: "Select State",
                          allowClear: true
                      });
                    $('#city-dd').html('<option value="">Select City</option>');
                }
            });
        });
        $('#state-dd').on('change', function () {
            var idState = this.value;
            $("#city-dd").html('');
            $.ajax({
                url: "{{url('api/fetch-cities')}}",
                type: "POST",
                data: {
                    state_id: idState,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (res) {
                    $('#city-dd').html('<option value="">Select City</option>');
                    $.each(res.cities, function (key, value) {
                        $("#city-dd").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                    $("#city-dd").select2("destroy").select2({
                        placeholder: "Select City",
                        allowClear: true
                    });
                }
            });
        });



    });
  </script>
@endsection
