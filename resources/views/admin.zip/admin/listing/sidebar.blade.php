<div class="bs-stepper-header">
  <div class="step" data-target="#account-details-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_information') == 1) ? url('listing/information/'.$listing->id) : ''}}"
     type="button" class="step-trigger" {{(empty($type)) ? '': ($type == 'information' ? ''  : 'disabled="disabled"')}} >
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Software information</span>
        <span class="bs-stepper-subtitle">Setup Software Details</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
  <div class="line"></div>
  <div class="step" data-target="#personal-info-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_description') == 1) ? url('listing/description/'.$listing->id) : ''}}"
     type="button" {{(!empty($type) && $type == 'description') ? '' : 'disabled="disabled"'}} class="step-trigger">
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Description</span>
        <span class="bs-stepper-subtitle">Add Description</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
  <div class="line"></div>
  <div class="step" data-target="#social-links-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_features') == 1) ? url('listing/features/'.$listing->id) : ''}}"
     type="button" {{(!empty($type) && $type == 'features') ? '' : 'disabled="disabled"'}} class="step-trigger">
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Features</span>
        <span class="bs-stepper-subtitle">Add Features</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
  <div class="line"></div>
  <div class="step" data-target="#social-links-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_media') == 1) ? url('listing/media/'.$listing->id) : ''}}"
     type="button" {{(!empty($type) && $type == 'media') ? '' : 'disabled="disabled"'}} class="step-trigger">
      
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Media</span>
        <span class="bs-stepper-subtitle">Add Media</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
  <div class="line"></div>
  <div class="step" data-target="#social-links-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_destination') == 1) ? url('listing/destination/'.$listing->id) : ''}}"
     type="button" {{(!empty($type) && $type == 'destination') ? '' : 'disabled="disabled"'}} class="step-trigger">
      
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Destination URLs</span>
        <span class="bs-stepper-subtitle">Add Destination URLs</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
  <div class="line"></div>
  <div class="step" data-target="#social-links-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_pricing') == 1) ? url('listing/pricing/'.$listing->id) : ''}}"
     type="button" {{(!empty($type) && $type == 'pricing') ? '' : 'disabled="disabled"'}} class="step-trigger">
      
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Pricing</span>
        <span class="bs-stepper-subtitle">Add Pricing & plans</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
  <div class="line"></div>
  <div class="step" data-target="#social-links-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_integration') == 1) ? url('listing/integration/'.$listing->id) : ''}}"
     type="button" {{(!empty($type) && $type == 'integration') ? '' : 'disabled="disabled"'}} class="step-trigger">
      
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Integration & API</span>
        <span class="bs-stepper-subtitle">Add Integration & API</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
  <div class="line"></div>
  <div class="step" data-target="#social-links-vertical">
    <button
    data-url="{{(!empty($listing) && $listing->getMeta('is_training') == 1) ? url('listing/training/'.$listing->id) : ''}}"
     type="button" {{(!empty($type) && $type == 'training') ? '' : 'disabled="disabled"'}} class="step-trigger">
      
      <span class="bs-stepper-label">
        <span class="bs-stepper-title">Support Training</span>
        <span class="bs-stepper-subtitle">Add Support details</span>
      </span>
      <span class="bs-stepper-circle">
        <i class="ti ti-arrow-right"></i>
      </span>
    </button>
  </div>
</div>
<div class="bs-stepper-content">
  @if(count($errors) > 0 )
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <ul class="p-0 m-0" style="list-style: none;">
      @foreach($errors->all() as $error)
      <li>{{$error}}</li>
      @endforeach
    </ul>
  </div>
  @endif